ILLUSTRATIVE EXAMPLE - InvoicePilot is a fictional sample app. These files are rendered illustrations, not real customer work or footage.
